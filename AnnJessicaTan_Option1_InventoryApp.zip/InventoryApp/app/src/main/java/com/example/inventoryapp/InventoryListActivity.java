package com.example.inventoryapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_list);
    }
}