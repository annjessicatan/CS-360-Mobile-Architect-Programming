package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper - Manages SQLite database for user authentication and inventory management
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 1;

    // Users table - KEEP ORIGINAL COLUMN NAMES
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Inventory items table - KEEP ORIGINAL COLUMN NAMES
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ITEM_ID = "item_id";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_QUANTITY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("DatabaseHelper", "Creating database tables");

        // Create users table with ORIGINAL column names
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT UNIQUE,"
                + COLUMN_PASSWORD + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);
        Log.d("DatabaseHelper", "Users table created");

        // Create inventory table with ORIGINAL column names
        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + "("
                + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_ITEM_NAME + " TEXT,"
                + COLUMN_QUANTITY + " INTEGER" + ")";
        db.execSQL(CREATE_INVENTORY_TABLE);
        Log.d("DatabaseHelper", "Inventory table created");

        // Add sample data
        addSampleInventoryData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    private void addSampleInventoryData(SQLiteDatabase db) {
        Log.d("DatabaseHelper", "Adding sample inventory data");

        String[] itemNames = {"Laptop", "Mouse", "Keyboard", "Monitor", "Headphones"};
        int[] quantities = {5, 15, 10, 8, 12};

        for (int i = 0; i < itemNames.length; i++) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_ITEM_NAME, itemNames[i]);
            values.put(COLUMN_QUANTITY, quantities[i]);
            db.insert(TABLE_INVENTORY, null, values);
        }
        Log.d("DatabaseHelper", "Sample inventory data added");
    }

    // User management methods
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        Log.d("DatabaseHelper", "addUser: " + username + " - Result: " + result);
        return result != -1;
    }

    public boolean checkUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + " = ?",
                new String[]{username},
                null, null, null);

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        Log.d("DatabaseHelper", "checkUsername: " + username + " - Exists: " + exists);
        return exists;
    }

    public boolean checkUserCredentials(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?",
                new String[]{username, password},
                null, null, null);

        boolean valid = cursor.getCount() > 0;
        cursor.close();
        Log.d("DatabaseHelper", "checkUserCredentials: " + username + " - Valid: " + valid);
        return valid;
    }

    // Inventory CRUD operations
    public long addInventoryItem(String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_QUANTITY, quantity);

        long result = db.insert(TABLE_INVENTORY, null, values);
        Log.d("DatabaseHelper", "addInventoryItem: " + itemName + " - Result: " + result);
        return result;
    }

    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_INVENTORY,
                new String[]{COLUMN_ITEM_ID, COLUMN_ITEM_NAME, COLUMN_QUANTITY},
                null, null, null, null, COLUMN_ITEM_NAME + " ASC");

        if (cursor.moveToFirst()) {
            do {
                InventoryItem item = new InventoryItem();
                item.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID)));
                item.setItemName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME)));
                item.setQuantity(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY)));
                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        Log.d("DatabaseHelper", "getAllInventoryItems: Retrieved " + itemList.size() + " items");
        return itemList;
    }

    public boolean updateInventoryItem(int id, String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_QUANTITY, quantity);

        int rowsAffected = db.update(TABLE_INVENTORY, values,
                COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(id)});
        Log.d("DatabaseHelper", "updateInventoryItem: ID=" + id + " - Rows affected: " + rowsAffected);
        return rowsAffected > 0;
    }

    public boolean deleteInventoryItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_INVENTORY,
                COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(id)});
        Log.d("DatabaseHelper", "deleteInventoryItem: ID=" + id + " - Rows affected: " + rowsAffected);
        return rowsAffected > 0;
    }

    public InventoryItem getInventoryItem(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY,
                new String[]{COLUMN_ITEM_ID, COLUMN_ITEM_NAME, COLUMN_QUANTITY},
                COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(id)},
                null, null, null);

        InventoryItem item = null;
        if (cursor != null && cursor.moveToFirst()) {
            item = new InventoryItem();
            item.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID)));
            item.setItemName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME)));
            item.setQuantity(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY)));
            cursor.close();
        }
        return item;
    }
}