package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername, editTextPassword;
    private Button buttonLogin, buttonCreateAccount, buttonSmsPermission;
    private TextView textViewSmsStatus;
    private DatabaseHelper databaseHelper;
    private static final String TAG = "MainActivity";

    // SMS Permission request code
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG, "onCreate: Activity started");

        try {
            // Initialize database helper
            databaseHelper = new DatabaseHelper(this);
            Log.d(TAG, "onCreate: DatabaseHelper initialized successfully");
        } catch (Exception e) {
            Log.e(TAG, "onCreate: Failed to initialize DatabaseHelper", e);
            Toast.makeText(this, "Database initialization failed", Toast.LENGTH_LONG).show();
            return;
        }

        // Initialize views
        initializeViews();

        // Set up SMS permission status
        updateSmsPermissionStatus();

        // Set click listeners
        setupClickListeners();
    }

    /**
     * Initialize all UI views with proper error handling
     */
    private void initializeViews() {
        try {
            editTextUsername = findViewById(R.id.editTextUsername);
            editTextPassword = findViewById(R.id.editTextPassword);
            buttonLogin = findViewById(R.id.buttonLogin);
            buttonCreateAccount = findViewById(R.id.buttonCreateNewAccount);
            buttonSmsPermission = findViewById(R.id.buttonSmsPermission);
            textViewSmsStatus = findViewById(R.id.textViewSmsStatus);

            if (editTextUsername == null || editTextPassword == null ||
                    buttonLogin == null || buttonCreateAccount == null ||
                    buttonSmsPermission == null || textViewSmsStatus == null) {
                throw new RuntimeException("One or more views not found in layout");
            }

            Log.d(TAG, "initializeViews: All views initialized successfully");
        } catch (Exception e) {
            Log.e(TAG, "initializeViews: Failed to initialize views", e);
            Toast.makeText(this, "UI initialization failed", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    /**
     * Set up click listeners for buttons
     */
    private void setupClickListeners() {
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Login button clicked");
                handleLogin();
            }
        });

        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Create Account button clicked");
                handleCreateAccount();
            }
        });

        buttonSmsPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "SMS Permission button clicked");
                handleSmsPermissionRequest();
            }
        });
    }

    /**
     * Update SMS permission status display
     */
    private void updateSmsPermissionStatus() {
        if (hasSmsPermission()) {
            textViewSmsStatus.setText("SMS alerts are enabled");
            buttonSmsPermission.setText("DISABLE");
            buttonSmsPermission.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.holo_red_light));
            Log.d(TAG, "updateSmsPermissionStatus: SMS permission granted");
        } else {
            textViewSmsStatus.setText("SMS alerts are disabled");
            buttonSmsPermission.setText("ENABLE");
            buttonSmsPermission.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.holo_green_light));
            Log.d(TAG, "updateSmsPermissionStatus: SMS permission not granted");
        }
    }

    /**
     * Check if SMS permission is granted
     */
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Handle SMS permission request
     */
    private void handleSmsPermissionRequest() {
        if (hasSmsPermission()) {
            // Permission already granted - show option to send test SMS
            showTestSmsDialog();
        } else {
            // Request permission
            Log.d(TAG, "handleSmsPermissionRequest: Requesting SMS permission");
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    /**
     * Handle permission request result
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Log.i(TAG, "onRequestPermissionsResult: SMS permission granted");
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
                updateSmsPermissionStatus();

                // Send welcome SMS
                sendWelcomeSms();

            } else {
                // Permission denied
                Log.w(TAG, "onRequestPermissionsResult: SMS permission denied");
                Toast.makeText(this, "SMS permission denied. Alerts will not work.", Toast.LENGTH_LONG).show();
                updateSmsPermissionStatus();
            }
        }
    }

    /**
     * Send welcome SMS when permission is first granted
     */
    private void sendWelcomeSms() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = "1234567890"; // Demo number - in real app, get from user
            String message = "Welcome to Inventory Manager! Low inventory alerts are now enabled.";

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Log.i(TAG, "sendWelcomeSms: Welcome SMS sent successfully");
            Toast.makeText(this, "Welcome SMS sent!", Toast.LENGTH_SHORT).show();

        } catch (SecurityException e) {
            Log.e(TAG, "sendWelcomeSms: Security exception - no SMS permission", e);
            Toast.makeText(this, "Cannot send SMS: Permission required", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "sendWelcomeSms: Failed to send SMS", e);
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Show dialog to send test SMS
     */
    private void showTestSmsDialog() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("Test SMS Alert")
                .setMessage("Send a test low inventory alert via SMS?")
                .setPositiveButton("Send Test", (dialog, which) -> {
                    sendTestLowInventoryAlert();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Send test low inventory alert
     */
    private void sendTestLowInventoryAlert() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = "1234567890"; // Demo number
            String message = "ALERT: Test item is running low (Quantity: 2). Please restock soon.";

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Log.i(TAG, "sendTestLowInventoryAlert: Test alert SMS sent successfully");
            Toast.makeText(this, "Test alert sent!", Toast.LENGTH_SHORT).show();

        } catch (SecurityException e) {
            Log.e(TAG, "sendTestLowInventoryAlert: Security exception", e);
            Toast.makeText(this, "Cannot send SMS: Permission required", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "sendTestLowInventoryAlert: Failed to send test SMS", e);
            Toast.makeText(this, "Failed to send test alert", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handles user login by validating credentials against the database
     */
    private void handleLogin() {
        try {
            String username = editTextUsername.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            Log.d(TAG, "handleLogin: Attempting login for user: " + username);

            // Validate input fields
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this,
                        "Please fill in all fields", Toast.LENGTH_SHORT).show();
                Log.w(TAG, "handleLogin: Validation failed - empty fields");
                return;
            }

            // Check user credentials in database
            boolean isValidUser = databaseHelper.checkUserCredentials(username, password);
            Log.d(TAG, "handleLogin: Database validation result: " + isValidUser);

            if (isValidUser) {
                // Login successful - navigate to inventory screen
                Toast.makeText(MainActivity.this,
                        "Login successful!", Toast.LENGTH_SHORT).show();
                Log.i(TAG, "handleLogin: Login successful for user: " + username);

                // Send login notification SMS if permission granted
                if (hasSmsPermission()) {
                    sendLoginNotificationSms(username);
                }

                // Navigate to inventory screen with error handling
                navigateToInventory();

                // Clear password field for security
                editTextPassword.setText("");
            } else {
                // Login failed
                Toast.makeText(MainActivity.this,
                        "Invalid username or password", Toast.LENGTH_SHORT).show();
                Log.w(TAG, "handleLogin: Login failed for user: " + username);
            }
        } catch (Exception e) {
            Log.e(TAG, "handleLogin: Unexpected error during login", e);
            Toast.makeText(this, "Login error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Send login notification SMS
     */
    private void sendLoginNotificationSms(String username) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = "1234567890"; // Demo number
            String message = "Inventory Manager: User " + username + " logged in successfully.";

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Log.i(TAG, "sendLoginNotificationSms: Login notification sent for user: " + username);

        } catch (Exception e) {
            Log.e(TAG, "sendLoginNotificationSms: Failed to send login notification", e);
            // Don't show error to user - SMS is optional
        }
    }

    /**
     * Navigate to InventoryListActivity with error handling
     */
    private void navigateToInventory() {
        try {
            Log.d(TAG, "navigateToInventory: Starting navigation to InventoryListActivity");

            Intent intent = new Intent(MainActivity.this, InventoryListActivity.class);

            // Add flags to clear the back stack
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

            Log.d(TAG, "navigateToInventory: Intent created, starting activity...");
            startActivity(intent);

            Log.d(TAG, "navigateToInventory: Activity started successfully");

            // Finish current activity so user can't go back to login
            finish();

        } catch (Exception e) {
            Log.e(TAG, "navigateToInventory: Failed to start InventoryListActivity", e);
            Toast.makeText(this, "Cannot open inventory screen: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Handles new user account creation
     */
    private void handleCreateAccount() {
        try {
            String username = editTextUsername.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            Log.d(TAG, "handleCreateAccount: Attempting to create account for user: " + username);

            // Validate input fields
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this,
                        "Please fill in all fields", Toast.LENGTH_SHORT).show();
                Log.w(TAG, "handleCreateAccount: Validation failed - empty fields");
                return;
            }

            // Check if username already exists
            boolean usernameExists = databaseHelper.checkUsername(username);
            Log.d(TAG, "handleCreateAccount: Username exists check: " + usernameExists);

            if (usernameExists) {
                Toast.makeText(MainActivity.this,
                        "Username already exists", Toast.LENGTH_SHORT).show();
                Log.w(TAG, "handleCreateAccount: Username already exists: " + username);
                return;
            }

            // Create new user account
            boolean accountCreated = databaseHelper.addUser(username, password);
            Log.d(TAG, "handleCreateAccount: Account creation result: " + accountCreated);

            if (accountCreated) {
                Toast.makeText(MainActivity.this,
                        "Account created successfully!", Toast.LENGTH_SHORT).show();
                Log.i(TAG, "handleCreateAccount: Account created successfully for user: " + username);

                // Send welcome SMS if permission granted
                if (hasSmsPermission()) {
                    sendWelcomeSms();
                }

                // Clear password field
                editTextPassword.setText("");
            } else {
                Toast.makeText(MainActivity.this,
                        "Failed to create account", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "handleCreateAccount: Failed to create account for user: " + username);
            }
        } catch (Exception e) {
            Log.e(TAG, "handleCreateAccount: Unexpected error during account creation", e);
            Toast.makeText(this, "Account creation error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close database connection when activity is destroyed
        if (databaseHelper != null) {
            databaseHelper.close();
            Log.d(TAG, "onDestroy: DatabaseHelper closed");
        }
    }
}