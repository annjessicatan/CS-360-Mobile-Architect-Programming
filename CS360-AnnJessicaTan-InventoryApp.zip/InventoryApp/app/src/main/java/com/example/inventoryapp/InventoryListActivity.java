package com.example.inventoryapp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class InventoryListActivity extends AppCompatActivity {

    private RecyclerView recyclerViewInventory;
    private FloatingActionButton fabAddItem;
    private InventoryAdapter adapter;
    private DatabaseHelper databaseHelper;
    private List<InventoryItem> inventoryItems;
    private static final String TAG = "InventoryListActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_list);
        Log.d(TAG, "onCreate: InventoryListActivity started");

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        initializeViews();

        // Setup RecyclerView
        setupRecyclerView();

        // Load inventory items
        loadInventoryItems();

        // Set up click listeners
        setupClickListeners();
    }

    private void initializeViews() {
        recyclerViewInventory = findViewById(R.id.recyclerViewInventory);
        fabAddItem = findViewById(R.id.fabAddItem);

        if (recyclerViewInventory == null) {
            Log.e(TAG, "initializeViews: RecyclerView not found!");
            Toast.makeText(this, "Error initializing inventory list", Toast.LENGTH_LONG).show();
            finish();
        }

        if (fabAddItem == null) {
            Log.e(TAG, "initializeViews: FAB not found!");
        }
    }

    private void setupRecyclerView() {
        // Set layout manager
        recyclerViewInventory.setLayoutManager(new LinearLayoutManager(this));

        // Initialize adapter with empty list
        inventoryItems = databaseHelper.getAllInventoryItems();
        adapter = new InventoryAdapter(inventoryItems);

        // Set item click listener
        adapter.setOnItemClickListener(new InventoryAdapter.OnItemClickListener() {
            @Override
            public void onDeleteClick(int position) {
                showDeleteConfirmationDialog(position);
            }

            @Override
            public void onItemClick(int position) {
                // Handle item click (for future update functionality)
                InventoryItem item = inventoryItems.get(position);
                showUpdateItemDialog(position, item);
            }
        });

        // Set adapter to RecyclerView
        recyclerViewInventory.setAdapter(adapter);
        Log.d(TAG, "setupRecyclerView: RecyclerView setup completed");
    }

    private void setupClickListeners() {
        if (fabAddItem != null) {
            fabAddItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showAddItemDialog();
                }
            });
        }
    }

    private void loadInventoryItems() {
        inventoryItems = databaseHelper.getAllInventoryItems();
        if (adapter != null) {
            adapter.setInventoryItems(inventoryItems);
            Log.d(TAG, "loadInventoryItems: Loaded " + inventoryItems.size() + " items");

            // Show message if no items
            if (inventoryItems.isEmpty()) {
                Toast.makeText(this, "No inventory items found. Add some items using the + button.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        // Create input fields programmatically
        final EditText itemNameInput = new EditText(this);
        itemNameInput.setHint("Item Name");

        final EditText quantityInput = new EditText(this);
        quantityInput.setHint("Quantity");
        quantityInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        // Create layout for inputs
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);
        layout.addView(itemNameInput);
        layout.addView(quantityInput);

        builder.setView(layout);

        // Set up the buttons
        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String itemName = itemNameInput.getText().toString().trim();
                String quantityStr = quantityInput.getText().toString().trim();

                if (itemName.isEmpty()) {
                    Toast.makeText(InventoryListActivity.this, "Please enter item name", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (quantityStr.isEmpty()) {
                    Toast.makeText(InventoryListActivity.this, "Please enter quantity", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int quantity = Integer.parseInt(quantityStr);

                    // Add item to database
                    long result = databaseHelper.addInventoryItem(itemName, quantity);
                    if (result != -1) {
                        Toast.makeText(InventoryListActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();
                        loadInventoryItems(); // Refresh the list
                    } else {
                        Toast.makeText(InventoryListActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(InventoryListActivity.this, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void showUpdateItemDialog(final int position, InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Item");

        // Create input fields with current values
        final EditText itemNameInput = new EditText(this);
        itemNameInput.setText(item.getItemName());
        itemNameInput.setHint("Item Name");

        final EditText quantityInput = new EditText(this);
        quantityInput.setText(String.valueOf(item.getQuantity()));
        quantityInput.setHint("Quantity");
        quantityInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        // Create layout for inputs
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);
        layout.addView(itemNameInput);
        layout.addView(quantityInput);

        builder.setView(layout);

        // Set up the buttons
        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String itemName = itemNameInput.getText().toString().trim();
                String quantityStr = quantityInput.getText().toString().trim();

                if (itemName.isEmpty()) {
                    Toast.makeText(InventoryListActivity.this, "Please enter item name", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (quantityStr.isEmpty()) {
                    Toast.makeText(InventoryListActivity.this, "Please enter quantity", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int quantity = Integer.parseInt(quantityStr);

                    // Update item in database
                    boolean success = databaseHelper.updateInventoryItem(item.getId(), itemName, quantity);
                    if (success) {
                        Toast.makeText(InventoryListActivity.this, "Item updated successfully", Toast.LENGTH_SHORT).show();
                        loadInventoryItems(); // Refresh the list
                    } else {
                        Toast.makeText(InventoryListActivity.this, "Failed to update item", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(InventoryListActivity.this, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    private void showDeleteConfirmationDialog(final int position) {
        InventoryItem item = inventoryItems.get(position);

        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Are you sure you want to delete " + item.getItemName() + "?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteItem(position);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteItem(int position) {
        InventoryItem item = inventoryItems.get(position);
        boolean deleted = databaseHelper.deleteInventoryItem(item.getId());

        if (deleted) {
            // Remove from the list and notify adapter
            inventoryItems.remove(position);
            adapter.notifyItemRemoved(position);
            Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();

            // Show message if no items left
            if (inventoryItems.isEmpty()) {
                Toast.makeText(this, "All items deleted. Add new items using the + button.", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}